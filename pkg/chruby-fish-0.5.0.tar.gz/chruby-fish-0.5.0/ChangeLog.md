# CHANGELOG

## v0.5.0 (2014-04-04)

### Features

- Initial commit of `chruby-fish` wrapper scripts
