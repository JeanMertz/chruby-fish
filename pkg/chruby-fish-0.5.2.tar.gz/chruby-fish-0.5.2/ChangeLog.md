# CHANGELOG

## v0.5.2 (2014-04-24)

### Fixes

- Make chruby_auto only run on path changes and not override manual `chruby`

## v0.5.1 (2014-04-24)

### Improvements

- Clean up files

## v0.5.0 (2014-04-23)

### Features

- Initial commit of `chruby-fish` wrapper scripts
